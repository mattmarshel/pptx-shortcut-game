/* ======================================
   POWERPOINT MASTER — APP JS
   With animated visual illustrations
   ====================================== */

// ===== SHORTCUT DATA =====
const SHORTCUTS = [
    { title: "Wrap Text", key: "Ctrl+7", macKey: "Cmd+7", category: "Formatting" },
    { title: "Do Not Wrap Text", key: "Ctrl+Shift+7", macKey: "Cmd+Shift+7", category: "Formatting" },
    { title: "Quick Keys", key: "Ctrl+Alt+Q", category: "Tools" },
    { title: "Toggle Moons, Shapes and Flows (e.g. Cycle Harvey Ball states)", key: "Ctrl+T", macKey: "Control+T", category: "Shapes", mustHave: true },
    { title: "Make Same Size", key: "Alt+Z", macKey: "Option+Z", category: "Alignment", mustHave: true },
    { title: "Make Same Height", key: "Ctrl+Shift+E", macKey: "Cmd+Shift+E", category: "Alignment" },
    { title: "Make Same Width", key: "Ctrl+Alt+E", macKey: "Cmd+Option+E", category: "Alignment" },
    { title: "Insert Textbox", key: "Alt+Q", macKey: "Control+Q", category: "Insert", mustHave: true },
    { title: "Text to Autoshape", key: "Alt+Shift+Z", category: "Shapes" },
    { title: "Align and Group", key: "Alt+G", macKey: "Option+G", category: "Alignment" },
    { title: "Copy Position", key: "Ctrl+1", macKey: "Option+1", category: "Position" },
    { title: "Paste Position", key: "Ctrl+2", macKey: "Option+2", category: "Position" },
    { title: "Normal View", key: "Ctrl+3", macKey: "Cmd+1", category: "View" },
    { title: "Slide Sorter View", key: "Ctrl+4", macKey: "Cmd+2", category: "View" },
    { title: "Fit to Window", key: "Ctrl+5", macKey: "Cmd+Option+O", category: "View" },
    { title: "Insert Flag", key: "Ctrl+6", category: "Insert" },
    { title: "Insert Sticky Note", key: "Ctrl+0", macKey: "Cmd+0", category: "Insert", mustHave: true },
    { title: "Insert Sticker", key: "Ctrl+Alt+S", macKey: "Cmd+Option+S", category: "Insert" },
    { title: "Insert Legend", key: "Ctrl+Alt+L", macKey: "Control+Option+L", category: "Insert" },
    { title: "Reset Fixed Elements", key: "Ctrl+Alt+R", macKey: "Control+Option+R", category: "Tools" },
    { title: "Split/Join Textboxes", key: "Ctrl+Alt+J", macKey: "Control+Option+J", category: "Tools" },
    { title: "Align Vertically", key: "Ctrl+Alt+M", macKey: "Control+Cmd+M", category: "Alignment" },
    { title: "Align Horizontally", key: "Ctrl+Alt+C", macKey: "Control+Cmd+C", category: "Alignment" },
    { title: "Align Left", key: "Ctrl+Alt+Left Arrow", macKey: "Control+Cmd+Left Arrow", category: "Alignment", mustHave: true },
    { title: "Align Right", key: "Ctrl+Alt+Right Arrow", macKey: "Control+Cmd+Right Arrow", category: "Alignment", mustHave: true },
    { title: "Align Top", key: "Ctrl+Alt+Up Arrow", macKey: "Control+Cmd+Up Arrow", category: "Alignment", mustHave: true },
    { title: "Align Bottom", key: "Ctrl+Alt+Down Arrow", macKey: "Control+Cmd+Down Arrow", category: "Alignment", mustHave: true },
    { title: "Distribute Vertically", key: "Alt+Shift+V", macKey: "Option+Shift+V", category: "Alignment", mustHave: true },
    { title: "Distribute Horizontally", key: "Alt+Shift+H", macKey: "Option+Shift+H", category: "Alignment", mustHave: true },
    { title: "Paste Unformatted Text", key: "Ctrl+Alt+T", category: "Formatting", mustHave: true },
    { title: "Resize Shape to Fit Text", key: "Ctrl+8", altKey: "Ctrl+Shift+W", macKey: "Cmd+8", category: "Shapes", mustHave: true },
    { title: "Apply Default Text Format", key: "Ctrl+Space", macKey: "Control+Spacebar", category: "Formatting" },
    { title: "Cycle Accent Colors", key: "Alt+Shift+A", category: "Formatting" },
    { title: "Insert New Slide", key: "Ctrl+M", macKey: "Cmd+Shift+N", category: "Insert" },
    { title: "Change Font Size", key: "Ctrl+Shift+O", category: "Formatting" },
    { title: "Group", key: "Ctrl+G", macKey: "Cmd+Option+G", category: "Alignment", mustHave: true },
    { title: "Ungroup", key: "Ctrl+Shift+G", macKey: "Cmd+Option+Shift+G", category: "Alignment", mustHave: true },
    { title: "Copy Style", key: "Ctrl+Shift+C", macKey: "Cmd+Shift+C", category: "Formatting", mustHave: true },
    { title: "Paste Style", key: "Ctrl+Shift+V", macKey: "Cmd+Shift+V", category: "Formatting", mustHave: true },
    { title: "Green Print", key: "Ctrl+Alt+P", category: "Print" },
    { title: "Green Print Two Slides", key: "Ctrl+Alt+2", category: "Print" },
    { title: "Green Print Four Slides", key: "Ctrl+Alt+4", category: "Print" },
    { title: "Insert Footnote", key: "Ctrl+Alt+F", macKey: "Cmd+Option+F", category: "Insert" },
    { title: "Increase Text Indentation List Level", key: "Alt+Shift+Right Arrow", macKey: "Cmd+]", category: "Lists", mustHave: true },
    { title: "Decrease Text Indentation List Level", key: "Alt+Shift+Left Arrow", macKey: "Cmd+[", category: "Lists", mustHave: true },
    { title: "List Line Spacing", key: "Ctrl+Shift+L", category: "Lists" },
    { title: "Bring to Front", key: "Alt+Shift+]", macKey: "Cmd+Shift+F", category: "Ordering" },
    { title: "Bring Forward", key: "Alt+]", macKey: "Cmd+Option+Shift+F", category: "Ordering" },
    { title: "Send to Back", key: "Alt+Shift+[", macKey: "Cmd+Shift+B", category: "Ordering" },
    { title: "Send Backward", key: "Alt+[", macKey: "Cmd+Option+Shift+B", category: "Ordering" },
    { title: "Shuffle Text Line Up", key: "Alt+Shift+Up Arrow", macKey: "Control+Shift+Up Arrow", category: "Formatting", mustHave: true },
    { title: "Shuffle Text Line Down", key: "Alt+Shift+Down Arrow", macKey: "Control+Shift+Down Arrow", category: "Formatting", mustHave: true },
    { title: "Increase Font Size", key: "Ctrl+Shift+>", macKey: "Cmd+Shift+>", category: "Formatting", mustHave: true },
    { title: "Decrease Font Size", key: "Ctrl+Shift+<", macKey: "Cmd+Shift+<", category: "Formatting", mustHave: true },
    { title: "Jump Between Objects", key: "Alt+Arrow Key", macKey: "Tab or Shift+Tab", category: "Tools" },
    { title: "Select Multiple Objects", key: "Click+Drag or Shift+Click", macKey: "Click+Drag or Shift+Click", category: "Mouse", mustHave: true },
    { title: "Move Horizontally / Vertically", key: "Shift+Drag", macKey: "Shift+Drag", category: "Mouse", mustHave: true },
    { title: "Copy Object", key: "Ctrl+Drag", macKey: "Control+Drag", category: "Mouse", mustHave: true },
    { title: "Copy + Move Horizontally / Vertically", key: "Ctrl+Shift+Drag", macKey: "Control+Shift+Drag", category: "Mouse", mustHave: true },
    { title: "Zoom In / Out", key: "Ctrl+Scroll", macKey: "Cmd+Scroll", category: "Mouse", mustHave: true }
];

const CATEGORIES = [...new Set(SHORTCUTS.map(s => s.category))];

// ===== VISUAL GENERATORS =====
// Each returns an HTML string for an animated mini-slide illustration

function visTitleBar(label) {
    return `<div class="vis-title-bar"><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="bar-text">${label || 'PowerPoint'}</span></div>`;
}

const VISUALS = {
    "Wrap Text": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:12px;width:90px;height:55px;border:1.5px solid #B8CAFF;border-radius:3px;background:#F0F4FF"></div>
            <div style="position:absolute;left:20px;top:18px;font-size:6.5px;color:#333;font-family:Arial,Helvetica,sans-serif;animation:wrapText 4s ease-in-out infinite">
                The quick brown fox jumps over the lazy dog today
            </div>
            <div style="position:absolute;right:15px;top:16px;font-size:6px;color:#2251FF;font-weight:700">Ctrl+7</div>
            <div style="position:absolute;left:130px;top:50px;font-size:18px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8629;</div>
            <span class="vis-label">BEFORE &rarr; AFTER</span>
        </div></div>`,

    "Do Not Wrap Text": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:12px;width:90px;height:55px;border:1.5px solid #B8CAFF;border-radius:3px;background:#F0F4FF;overflow:hidden"></div>
            <div style="position:absolute;left:20px;top:18px;font-size:6.5px;color:#333;font-family:Arial,Helvetica,sans-serif;animation:unwrapText 4s ease-in-out infinite">
                The quick brown fox jumps over the lazy dog today
            </div>
            <div style="position:absolute;right:15px;top:16px;font-size:6px;color:#061F79;font-weight:700">Ctrl+Shift+7</div>
            <div style="position:absolute;left:130px;top:50px;font-size:14px;color:#061F79;animation:visPulse 4s ease-in-out infinite">&#8614;</div>
            <span class="vis-label">TEXT EXTENDS</span>
        </div></div>`,

    "Quick Keys": () => `<div class="vis">${visTitleBar('Tools')}
        <div class="vis-canvas">
            <div style="position:absolute;left:50%;top:45%;transform:translate(-50%,-50%);text-align:center">
                <div style="display:flex;gap:4px;margin-bottom:6px;justify-content:center">
                    <div style="width:22px;height:18px;background:#E8EEFF;border:1.5px solid #99B3FF;border-radius:3px;font-size:6px;display:flex;align-items:center;justify-content:center;font-weight:700;color:#2251FF;animation:insertAppear 4s ease-in-out infinite">Q</div>
                    <div style="width:22px;height:18px;background:#E8EEFF;border:1.5px solid #99B3FF;border-radius:3px;font-size:6px;display:flex;align-items:center;justify-content:center;font-weight:700;color:#2251FF;animation:insertAppear 4s ease-in-out infinite .2s">K</div>
                    <div style="width:22px;height:18px;background:#E8EEFF;border:1.5px solid #99B3FF;border-radius:3px;font-size:6px;display:flex;align-items:center;justify-content:center;font-weight:700;color:#2251FF;animation:insertAppear 4s ease-in-out infinite .4s">E</div>
                </div>
                <div style="font-size:6px;color:#3D4F5F">Show all shortcut overlays</div>
            </div>
            <span class="vis-label">QUICK KEYS</span>
        </div></div>`,

    "Toggle Moons, Shapes and Flows (e.g. Cycle Harvey Ball states)": () => `<div class="vis">${visTitleBar('Shapes')}
        <div class="vis-canvas">
            <div style="position:absolute;left:35px;top:25px;width:50px;height:50px;animation:shapeToggle 4s ease-in-out infinite"></div>
            <div style="position:absolute;left:35px;top:85px;font-size:6px;color:#888;text-align:center;width:50px">Before</div>
            <div style="position:absolute;right:45px;top:25px;width:50px;height:50px;border-radius:50%;background:#2251FF"></div>
            <div style="position:absolute;right:32px;top:85px;font-size:6px;color:#888;text-align:center;width:50px">After</div>
            <div style="position:absolute;left:50%;top:48px;transform:translateX(-50%);font-size:14px;color:#2251FF">&#8644;</div>
            <span class="vis-label">TOGGLE STATE</span>
        </div></div>`,

    "Make Same Size": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:15px;width:30px;height:20px;background:#4A73FF;border-radius:3px;animation:sameSize 4s ease-in-out infinite;--from-w:30px;--from-h:20px"></div>
            <div style="position:absolute;left:70px;top:10px;width:65px;height:55px;background:#2251FF;border-radius:3px;animation:sameSize 4s ease-in-out infinite;--from-w:65px;--from-h:55px"></div>
            <div style="position:absolute;right:30px;top:50%;transform:translateY(-50%);font-size:8px;color:#2251FF;font-weight:700;animation:visPulse 4s ease-in-out infinite">= SIZE</div>
            <span class="vis-label">SAME SIZE</span>
        </div></div>`,

    "Make Same Height": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:25px;top:20px;width:40px;height:24px;background:#4A73FF;border-radius:3px;animation:sameHeight 4s ease-in-out infinite;--from-h:24px"></div>
            <div style="position:absolute;left:80px;top:10px;width:40px;height:60px;background:#2251FF;border-radius:3px;animation:sameHeight 4s ease-in-out infinite;--from-h:60px"></div>
            <div style="position:absolute;right:25px;top:50%;transform:translateY(-50%);font-size:8px;color:#2251FF;font-weight:700;animation:visPulse 4s ease-in-out infinite">= H</div>
            <div style="position:absolute;left:10px;top:20px;width:1px;height:60px;border-left:1px dashed #aaa"></div>
            <span class="vis-label">SAME HEIGHT</span>
        </div></div>`,

    "Make Same Width": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:15px;width:25px;height:35px;background:#4A73FF;border-radius:3px;animation:sameWidth 4s ease-in-out infinite;--from-w:25px"></div>
            <div style="position:absolute;left:60px;top:15px;width:70px;height:35px;background:#2251FF;border-radius:3px;animation:sameWidth 4s ease-in-out infinite;--from-w:70px"></div>
            <div style="position:absolute;right:25px;top:50%;transform:translateY(-50%);font-size:8px;color:#2251FF;font-weight:700;animation:visPulse 4s ease-in-out infinite">= W</div>
            <span class="vis-label">SAME WIDTH</span>
        </div></div>`,

    "Insert Textbox": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas">
            <div style="position:absolute;left:50%;top:45%;transform:translate(-50%,-50%);width:120px;height:40px;border:2px solid #2251FF;border-radius:4px;background:white;animation:insertAppear 4s ease-in-out infinite;display:flex;align-items:center;padding-left:8px">
                <div style="width:1px;height:18px;background:#2251FF;animation:visPulse 1s ease infinite"></div>
                <span style="font-size:7px;color:#aaa;margin-left:4px">Type here...</span>
            </div>
            <div style="position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font-size:6px;color:#888">Textbox inserted</div>
            <span class="vis-label">INSERT</span>
        </div></div>`,

    "Text to Autoshape": () => `<div class="vis">${visTitleBar('Shapes')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:20px;width:80px;height:30px;border:1.5px solid #999;border-radius:3px;background:white;font-size:7px;display:flex;align-items:center;justify-content:center;color:#333">Text Box</div>
            <div style="position:absolute;left:50%;top:48px;transform:translateX(-50%);font-size:12px;color:#2251FF">&#10140;</div>
            <div style="position:absolute;left:20px;top:58px;width:80px;height:40px;border:2px solid #4A73FF;border-radius:20px;background:#E8EEFF;font-size:7px;display:flex;align-items:center;justify-content:center;color:#2251FF;animation:insertAppear 4s ease-in-out infinite">AutoShape</div>
            <span class="vis-label">CONVERT</span>
        </div></div>`,

    "Align and Group": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:12px;width:30px;height:25px;background:#4A73FF;border-radius:3px;animation:alignL 4s ease-in-out infinite;--from-x:15px"></div>
            <div style="position:absolute;left:90px;top:40px;width:35px;height:20px;background:#2251FF;border-radius:3px;animation:alignL 4s ease-in-out infinite;--from-x:90px"></div>
            <div style="position:absolute;left:50px;top:70px;width:25px;height:22px;background:#051C2C;border-radius:3px;animation:alignL 4s ease-in-out infinite;--from-x:50px"></div>
            <div style="position:absolute;left:8px;top:8px;width:70px;height:95px;border:2px dashed #2251FF;border-radius:4px;animation:groupShow 4s ease-in-out infinite"></div>
            <span class="vis-label">ALIGN + GROUP</span>
        </div></div>`,

    "Copy Position": () => `<div class="vis">${visTitleBar('Position')}
        <div class="vis-canvas">
            <div style="position:absolute;left:30px;top:25px;width:45px;height:35px;background:#4A73FF;border-radius:3px;display:flex;align-items:center;justify-content:center">
                <span style="font-size:6px;color:white;font-weight:700">SOURCE</span>
            </div>
            <div style="position:absolute;left:30px;top:25px;width:45px;height:35px;border:2px dashed #2251FF;border-radius:3px;animation:visPulse 2s ease-in-out infinite"></div>
            <div style="position:absolute;left:35px;top:68px;font-size:6px;color:#2251FF;font-weight:600">x:30 y:25</div>
            <div style="position:absolute;right:30px;top:30px;font-size:14px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#128203;</div>
            <span class="vis-label">COPY POS</span>
        </div></div>`,

    "Paste Position": () => `<div class="vis">${visTitleBar('Position')}
        <div class="vis-canvas">
            <div style="position:absolute;left:30px;top:25px;width:45px;height:35px;border:1.5px dashed #aaa;border-radius:3px;background:#f5f5f5">
                <span style="font-size:6px;color:#999;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)">TARGET</span>
            </div>
            <div style="position:absolute;left:120px;top:15px;width:45px;height:35px;background:#2251FF;border-radius:3px;animation:alignL 4s ease-in-out infinite;--from-x:120px;display:flex;align-items:center;justify-content:center">
                <span style="font-size:6px;color:white;font-weight:700">OBJ</span>
            </div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:6px;color:#3D4F5F">Pastes to copied position</div>
            <span class="vis-label">PASTE POS</span>
        </div></div>`,

    "Normal View": () => `<div class="vis">${visTitleBar('View')}
        <div class="vis-canvas">
            <div style="position:absolute;left:8px;top:6px;width:40px;height:90px;background:#E8EEFF;border:1px solid #B8CAFF;border-radius:2px;padding:3px">
                <div style="width:100%;height:12px;background:white;border:1px solid #ddd;border-radius:1px;margin-bottom:2px"></div>
                <div style="width:100%;height:12px;background:#E8EEFF;border:1px solid #B8CAFF;border-radius:1px;margin-bottom:2px"></div>
                <div style="width:100%;height:12px;background:white;border:1px solid #ddd;border-radius:1px"></div>
            </div>
            <div style="position:absolute;left:55px;top:6px;width:100px;height:75px;background:white;border:2px solid #2251FF;border-radius:3px;display:flex;align-items:center;justify-content:center;animation:insertAppear 4s ease-in-out infinite">
                <div style="text-align:center"><div style="font-size:8px;font-weight:700;color:#2251FF">Slide</div><div style="font-size:6px;color:#888">Normal View</div></div>
            </div>
            <div style="position:absolute;left:55px;top:85px;width:100px;height:12px;background:#f5f5f5;border:1px solid #ddd;border-radius:2px;font-size:5px;color:#999;display:flex;align-items:center;padding-left:4px">Notes panel</div>
            <span class="vis-label">NORMAL</span>
        </div></div>`,

    "Slide Sorter View": () => `<div class="vis">${visTitleBar('View')}
        <div class="vis-canvas" style="display:flex;flex-wrap:wrap;gap:5px;padding:8px;align-content:flex-start">
            ${[1,2,3,4,5,6].map((n,i) => `<div style="width:42px;height:30px;background:white;border:1.5px solid ${i===0?'#2251FF':'#ddd'};border-radius:2px;font-size:6px;display:flex;align-items:center;justify-content:center;color:#888;animation:insertAppear 4s ease-in-out infinite ${i*0.15}s">Slide ${n}</div>`).join('')}
            <span class="vis-label">SORTER VIEW</span>
        </div></div>`,

    "Fit to Window": () => `<div class="vis">${visTitleBar('View')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="width:80%;height:80%;background:white;border:2px solid #2251FF;border-radius:3px;display:flex;align-items:center;justify-content:center;animation:zoomFit 4s ease-in-out infinite">
                <div style="text-align:center"><div style="font-size:9px;font-weight:700;color:#2251FF">&#x2922;</div><div style="font-size:6px;color:#888">Fit to Window</div></div>
            </div>
            <span class="vis-label">ZOOM FIT</span>
        </div></div>`,

    "Insert Flag": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="animation:insertAppear 4s ease-in-out infinite;text-align:center">
                <div style="font-size:32px">&#127988;</div>
                <div style="font-size:6px;color:#888;margin-top:4px">Flag inserted on slide</div>
            </div>
            <span class="vis-label">INSERT FLAG</span>
        </div></div>`,

    "Insert Sticky Note": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="width:80px;height:70px;background:#FFF9C4;border:1px solid #FFE082;border-radius:2px;box-shadow:2px 2px 6px rgba(0,0,0,.1);padding:6px;animation:insertAppear 4s ease-in-out infinite">
                <div style="font-size:6px;color:#F57F17;font-weight:700;margin-bottom:3px">Note</div>
                <div style="font-size:5.5px;color:#888;line-height:1.4">Remember to<br>check this slide</div>
            </div>
            <span class="vis-label">STICKY NOTE</span>
        </div></div>`,

    "Insert Sticker": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="animation:insertAppear 4s ease-in-out infinite;text-align:center">
                <div style="width:50px;height:50px;background:#E8EEFF;border:2px solid #4A73FF;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px">&#9733;</div>
                <div style="font-size:6px;color:#888;margin-top:6px">Sticker added</div>
            </div>
            <span class="vis-label">INSERT STICKER</span>
        </div></div>`,

    "Insert Legend": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas">
            <div style="position:absolute;right:15px;top:10px;width:80px;background:white;border:1.5px solid #B8CAFF;border-radius:4px;padding:5px;animation:insertAppear 4s ease-in-out infinite">
                <div style="font-size:6px;font-weight:700;color:#333;margin-bottom:4px">Legend</div>
                <div style="display:flex;align-items:center;gap:4px;margin-bottom:2px"><div style="width:10px;height:6px;background:#4A73FF;border-radius:1px"></div><span style="font-size:5px;color:#666">Series A</span></div>
                <div style="display:flex;align-items:center;gap:4px;margin-bottom:2px"><div style="width:10px;height:6px;background:#2251FF;border-radius:1px"></div><span style="font-size:5px;color:#666">Series B</span></div>
                <div style="display:flex;align-items:center;gap:4px"><div style="width:10px;height:6px;background:#051C2C;border-radius:1px"></div><span style="font-size:5px;color:#666">Series C</span></div>
            </div>
            <div style="position:absolute;left:12px;top:15px;width:50px;height:65px;background:#f5f5f5;border:1px solid #ddd;border-radius:3px;display:flex;align-items:flex-end;padding:4px;gap:3px">
                <div style="width:10px;background:#4A73FF;height:60%;border-radius:2px 2px 0 0"></div>
                <div style="width:10px;background:#2251FF;height:80%;border-radius:2px 2px 0 0"></div>
                <div style="width:10px;background:#051C2C;height:45%;border-radius:2px 2px 0 0"></div>
            </div>
            <span class="vis-label">LEGEND</span>
        </div></div>`,

    "Reset Fixed Elements": () => `<div class="vis">${visTitleBar('Tools')}
        <div class="vis-canvas">
            <div style="position:absolute;left:25px;top:15px;width:30px;height:25px;background:#4A73FF;border-radius:3px;opacity:.6;animation:alignL 4s ease-in-out infinite;--from-x:80px"></div>
            <div style="position:absolute;left:70px;top:45px;width:35px;height:20px;background:#6B8FFF;border-radius:3px;opacity:.6;animation:alignL 4s ease-in-out infinite;--from-x:20px"></div>
            <div style="position:absolute;left:50%;top:80px;transform:translateX(-50%);font-size:14px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8634;</div>
            <div style="position:absolute;left:50%;bottom:4px;transform:translateX(-50%);font-size:6px;color:#888">Elements snap to default</div>
            <span class="vis-label">RESET</span>
        </div></div>`,

    "Split/Join Textboxes": () => `<div class="vis">${visTitleBar('Tools')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:14px;font-size:6px;color:#888;font-weight:600">BEFORE:</div>
            <div style="position:absolute;left:15px;top:26px;width:110px;height:22px;background:white;border:1.5px solid #2251FF;border-radius:3px;font-size:6px;display:flex;align-items:center;padding:0 6px;color:#333">Hello World! How are you?</div>
            <div style="position:absolute;left:50%;top:52px;transform:translateX(-50%);font-size:10px;color:#2251FF">&#8595;</div>
            <div style="position:absolute;left:15px;top:60px;font-size:6px;color:#888;font-weight:600">AFTER:</div>
            <div style="position:absolute;left:15px;top:72px;width:52px;height:22px;background:white;border:1.5px solid #4A73FF;border-radius:3px;font-size:6px;display:flex;align-items:center;padding:0 6px;color:#333;animation:insertAppear 4s ease-in-out infinite">Hello World!</div>
            <div style="position:absolute;left:75px;top:72px;width:52px;height:22px;background:white;border:1.5px solid #4A73FF;border-radius:3px;font-size:6px;display:flex;align-items:center;padding:0 6px;color:#333;animation:insertAppear 4s ease-in-out infinite .2s">How are you?</div>
            <span class="vis-label">SPLIT / JOIN</span>
        </div></div>`,

    "Align Vertically": () => makeAlignVisual('middle'),
    "Align Horizontally": () => makeAlignVisual('center'),
    "Align Left": () => makeAlignVisual('left'),
    "Align Right": () => makeAlignVisual('right'),
    "Align Top": () => makeAlignVisual('top'),
    "Align Bottom": () => makeAlignVisual('bottom'),

    "Distribute Vertically": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:40px;top:5px;width:45px;height:18px;background:#4A73FF;border-radius:3px;animation:distributeV 4s ease-in-out infinite;--from-y:5px;--to-y:8px"></div>
            <div style="position:absolute;left:40px;top:25px;width:45px;height:18px;background:#2251FF;border-radius:3px;animation:distributeV 4s ease-in-out infinite;--from-y:25px;--to-y:40px"></div>
            <div style="position:absolute;left:40px;top:70px;width:45px;height:18px;background:#051C2C;border-radius:3px;animation:distributeV 4s ease-in-out infinite;--from-y:70px;--to-y:72px"></div>
            <div style="position:absolute;right:20px;top:50%;transform:translateY(-50%) rotate(90deg);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8651;</div>
            <span class="vis-label">DISTRIBUTE V</span>
        </div></div>`,

    "Distribute Horizontally": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:5px;top:30px;width:25px;height:35px;background:#4A73FF;border-radius:3px;animation:distributeH 4s ease-in-out infinite;--from-x:5px;--to-x:15px"></div>
            <div style="position:absolute;left:40px;top:30px;width:25px;height:35px;background:#2251FF;border-radius:3px;animation:distributeH 4s ease-in-out infinite;--from-x:40px;--to-x:75px"></div>
            <div style="position:absolute;left:110px;top:30px;width:25px;height:35px;background:#051C2C;border-radius:3px;animation:distributeH 4s ease-in-out infinite;--from-x:110px;--to-x:135px"></div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8651;</div>
            <span class="vis-label">DISTRIBUTE H</span>
        </div></div>`,

    "Paste Unformatted Text": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:12px;font-size:6px;color:#888;font-weight:600">BEFORE:</div>
            <div style="position:absolute;left:15px;top:24px;font-size:10px;font-weight:700;font-style:italic;color:#061F79;font-family:Georgia,serif">Fancy Text Here</div>
            <div style="position:absolute;left:50%;top:46px;transform:translateX(-50%);font-size:10px;color:#2251FF">&#8595;</div>
            <div style="position:absolute;left:15px;top:56px;font-size:6px;color:#888;font-weight:600">AFTER:</div>
            <div style="position:absolute;left:15px;top:68px;font-size:9px;font-weight:400;color:#333;font-family:Arial,Helvetica,sans-serif;animation:insertAppear 4s ease-in-out infinite">Fancy Text Here</div>
            <span class="vis-label">UNFORMATTED</span>
        </div></div>`,

    "Resize Shape to Fit Text": () => `<div class="vis">${visTitleBar('Shapes')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:15px;width:70px;height:70px;background:#E8EEFF;border:2px solid #4A73FF;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:7px;color:#2251FF;animation:shapeToText 4s ease-in-out infinite">Abc</div>
            <div style="position:absolute;left:50%;top:42px;transform:translateX(-50%);font-size:14px;color:#2251FF">&#10140;</div>
            <div style="position:absolute;right:15px;top:25px;width:90px;height:28px;background:#E8EEFF;border:2px solid #4A73FF;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:7px;color:#2251FF;animation:insertAppear 4s ease-in-out infinite">Abc</div>
            <span class="vis-label">RESIZE TO FIT</span>
        </div></div>`,

    "Apply Default Text Format": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:12px;font-size:6px;color:#888;font-weight:600">BEFORE:</div>
            <div style="position:absolute;left:15px;top:24px;animation:formatStrip 4s ease-in-out infinite;font-family:Arial,Helvetica,sans-serif">Styled Text Sample</div>
            <div style="position:absolute;left:15px;top:52px;font-size:6px;color:#888;font-weight:600">AFTER:</div>
            <div style="position:absolute;left:15px;top:64px;font-size:9px;color:#333;font-weight:400;font-family:Arial,Helvetica,sans-serif">Styled Text Sample</div>
            <div style="position:absolute;right:15px;top:60px;font-size:14px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8998;</div>
            <span class="vis-label">DEFAULT FORMAT</span>
        </div></div>`,

    "Cycle Accent Colors": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center;gap:10px">
            <div style="width:55px;height:45px;border-radius:6px;animation:colorCycle 4s ease-in-out infinite"></div>
            <div style="text-align:center">
                <div style="font-size:18px;animation:visPulse 2s ease infinite">&#x1F3A8;</div>
                <div style="font-size:6px;color:#888;margin-top:3px">Colors cycle<br>through accents</div>
            </div>
            <span class="vis-label">CYCLE COLORS</span>
        </div></div>`,

    "Insert New Slide": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:10px;width:55px;height:40px;background:white;border:1.5px solid #ddd;border-radius:2px;display:flex;align-items:center;justify-content:center;font-size:6px;color:#999">Slide 1</div>
            <div style="position:absolute;left:80px;top:10px;width:55px;height:40px;background:white;border:2px solid #2251FF;border-radius:2px;display:flex;align-items:center;justify-content:center;font-size:6px;color:#2251FF;font-weight:700;animation:insertAppear 4s ease-in-out infinite">+ New</div>
            <div style="position:absolute;left:15px;top:58px;width:55px;height:40px;background:white;border:1.5px solid #ddd;border-radius:2px;display:flex;align-items:center;justify-content:center;font-size:6px;color:#999">Slide 2</div>
            <span class="vis-label">NEW SLIDE</span>
        </div></div>`,

    "Change Font Size": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="animation:fontGrow 4s ease-in-out infinite;color:#2251FF;font-weight:700;font-family:Arial,Helvetica,sans-serif">Aa</div>
            <span class="vis-label">FONT SIZE</span>
        </div></div>`,

    "Group": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:15px;width:35px;height:28px;background:#4A73FF;border-radius:3px"></div>
            <div style="position:absolute;left:45px;top:35px;width:30px;height:25px;background:#2251FF;border-radius:3px"></div>
            <div style="position:absolute;left:28px;top:58px;width:40px;height:20px;background:#051C2C;border-radius:3px"></div>
            <div style="position:absolute;left:14px;top:10px;width:68px;height:74px;border:2px dashed #2251FF;border-radius:4px;animation:groupShow 4s ease-in-out infinite"></div>
            <div style="position:absolute;right:20px;top:50%;transform:translateY(-50%);text-align:center">
                <div style="font-size:20px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#9744;</div>
                <div style="font-size:6px;color:#888">Group</div>
            </div>
            <span class="vis-label">GROUP</span>
        </div></div>`,

    "Ungroup": () => `<div class="vis">${visTitleBar('Alignment')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:15px;width:35px;height:28px;background:#4A73FF;border-radius:3px;animation:ungroupScatter 4s ease-in-out infinite;--from-x:20px;--from-y:15px;--to-x:8px;--to-y:5px"></div>
            <div style="position:absolute;left:45px;top:35px;width:30px;height:25px;background:#2251FF;border-radius:3px;animation:ungroupScatter 4s ease-in-out infinite;--from-x:45px;--from-y:35px;--to-x:70px;--to-y:15px"></div>
            <div style="position:absolute;left:28px;top:58px;width:40px;height:20px;background:#051C2C;border-radius:3px;animation:ungroupScatter 4s ease-in-out infinite;--from-x:28px;--from-y:58px;--to-x:15px;--to-y:72px"></div>
            <div style="position:absolute;left:14px;top:10px;width:68px;height:74px;border:2px dashed #2251FF;border-radius:4px;animation:ungroupHide 4s ease-in-out infinite"></div>
            <div style="position:absolute;right:18px;top:50%;transform:translateY(-50%);text-align:center">
                <div style="font-size:16px;color:#061F79;animation:visPulse 4s ease-in-out infinite">&#10005;</div>
                <div style="font-size:6px;color:#888">Ungroup</div>
            </div>
            <span class="vis-label">UNGROUP</span>
        </div></div>`,

    "Copy Style": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:20px;width:55px;height:40px;background:#4A73FF;border:2px solid #061F79;border-radius:4px;display:flex;align-items:center;justify-content:center;animation:stylePickup 4s ease-in-out infinite">
                <span style="font-size:7px;color:white;font-weight:700">Styled</span>
            </div>
            <div style="position:absolute;left:85px;top:25px;font-size:22px;animation:visPulse 4s ease-in-out infinite">&#128065;</div>
            <div style="position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font-size:6px;color:#888">Style copied</div>
            <span class="vis-label">COPY STYLE</span>
        </div></div>`,

    "Paste Style": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:25px;width:45px;height:35px;background:#4A73FF;border:2px solid #061F79;border-radius:4px;font-size:6px;color:white;display:flex;align-items:center;justify-content:center;font-weight:700">Source</div>
            <div style="position:absolute;left:50%;top:38px;transform:translateX(-50%);font-size:12px;color:#2251FF">&#10140;</div>
            <div style="position:absolute;right:20px;top:25px;width:45px;height:35px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:6px;font-weight:700;color:white;animation:styleApply 4s ease-in-out infinite">Target</div>
            <div style="position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font-size:6px;color:#888">Style pasted to target</div>
            <span class="vis-label">PASTE STYLE</span>
        </div></div>`,

    "Green Print": () => makePrintVisual(1),
    "Green Print Two Slides": () => makePrintVisual(2),
    "Green Print Four Slides": () => makePrintVisual(4),

    "Insert Footnote": () => `<div class="vis">${visTitleBar('Insert')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:8px;width:120px;height:55px;background:white;border:1px solid #ddd;border-radius:3px;padding:6px">
                <div style="font-size:6px;color:#333;line-height:1.5">Presentation content goes here<br>with important details<sup style="color:#2251FF;font-weight:700">1</sup></div>
            </div>
            <div style="position:absolute;left:15px;top:68px;width:120px;border-top:1px solid #ccc;padding-top:4px;animation:insertAppear 4s ease-in-out infinite">
                <div style="font-size:5px;color:#666"><sup style="color:#2251FF;font-weight:700">1</sup> This is the footnote text</div>
            </div>
            <span class="vis-label">FOOTNOTE</span>
        </div></div>`,

    "Increase Text Indentation List Level": () => `<div class="vis">${visTitleBar('Lists')}
        <div class="vis-canvas" style="padding:10px 15px">
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">&#8226; First item</div>
            <div style="font-size:6.5px;color:#2251FF;font-weight:600;animation:indentRight 4s ease-in-out infinite">&#8226; Second item</div>
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">&#8226; Third item</div>
            <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8618;</div>
            <span class="vis-label">INDENT +</span>
        </div></div>`,

    "Decrease Text Indentation List Level": () => `<div class="vis">${visTitleBar('Lists')}
        <div class="vis-canvas" style="padding:10px 15px">
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">&#8226; First item</div>
            <div style="font-size:6.5px;color:#2251FF;font-weight:600;animation:indentLeft 4s ease-in-out infinite">&#8226; Second item</div>
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">&#8226; Third item</div>
            <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8617;</div>
            <span class="vis-label">INDENT -</span>
        </div></div>`,

    "List Line Spacing": () => `<div class="vis">${visTitleBar('Lists')}
        <div class="vis-canvas" style="padding:10px 15px">
            <div style="font-size:6.5px;color:#333;animation:spacingExpand 4s ease-in-out infinite">
                &#8226; First item<br>
                &#8226; Second item<br>
                &#8226; Third item<br>
                &#8226; Fourth item
            </div>
            <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8693;</div>
            <span class="vis-label">LINE SPACING</span>
        </div></div>`,

    "Bring to Front": () => makeOrderVisual('front'),
    "Bring Forward": () => makeOrderVisual('forward'),
    "Send to Back": () => makeOrderVisual('back'),
    "Send Backward": () => makeOrderVisual('backward'),

    "Shuffle Text Line Up": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="padding:10px 15px">
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">First line of text</div>
            <div style="font-size:6.5px;color:#2251FF;font-weight:600;animation:alignT 4s ease-in-out infinite;--from-y:28px;position:absolute;left:15px;top:28px">Second line moves up</div>
            <div style="font-size:6.5px;color:#333;position:absolute;left:15px;top:42px">Third line of text</div>
            <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8593;</div>
            <span class="vis-label">SHUFFLE UP</span>
        </div></div>`,

    "Shuffle Text Line Down": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="padding:10px 15px">
            <div style="font-size:6.5px;color:#333;margin-bottom:4px">First line of text</div>
            <div style="font-size:6.5px;color:#2251FF;font-weight:600;animation:alignB 4s ease-in-out infinite;--from-y:28px;--to-y:42px;position:absolute;left:15px;top:28px">Second line moves down</div>
            <div style="font-size:6.5px;color:#333;position:absolute;left:15px;top:42px">Third line of text</div>
            <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">&#8595;</div>
            <span class="vis-label">SHUFFLE DOWN</span>
        </div></div>`,

    "Increase Font Size": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="animation:fontGrow 4s ease-in-out infinite;color:#2251FF;font-weight:700;font-family:Arial,Helvetica,sans-serif">A&#8599;</div>
            <span class="vis-label">SIZE UP</span>
        </div></div>`,

    "Decrease Font Size": () => `<div class="vis">${visTitleBar('Formatting')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="font-size:14px;color:#2251FF;font-weight:700;font-family:Arial,Helvetica,sans-serif;animation:fontGrow 4s ease-in-out infinite reverse">A&#8600;</div>
            <span class="vis-label">SIZE DOWN</span>
        </div></div>`,

    "Jump Between Objects": () => `<div class="vis">${visTitleBar('Tools')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:20px;width:35px;height:28px;background:#2251FF;border-radius:3px;display:flex;align-items:center;justify-content:center;font-size:6px;color:white;font-weight:700">A</div>
            <div style="position:absolute;left:65px;top:15px;width:30px;height:30px;background:#4A73FF;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:6px;color:white;font-weight:700">B</div>
            <div style="position:absolute;left:110px;top:22px;width:40px;height:25px;background:#051C2C;border-radius:3px;display:flex;align-items:center;justify-content:center;font-size:6px;color:white;font-weight:700">C</div>
            <div style="position:absolute;left:15px;top:60px;width:130px;height:0;border-top:1.5px dashed #2251FF"></div>
            <div style="position:absolute;left:30px;top:54px;font-size:10px;color:#2251FF;animation:distributeH 4s ease-in-out infinite;--from-x:30px;--to-x:120px">&#9650;</div>
            <div style="position:absolute;left:50%;bottom:6px;transform:translateX(-50%);font-size:6px;color:#8A95A0">Alt + any arrow key</div>
            <span class="vis-label">JUMP</span>
        </div></div>`,

    "Select Multiple Objects": () => `<div class="vis">${visTitleBar('Mouse')}
        <div class="vis-canvas">
            <div style="position:absolute;left:15px;top:15px;width:35px;height:28px;background:#2251FF;border-radius:3px;border:2px solid #061F79;animation:visPulse 4s ease-in-out infinite"></div>
            <div style="position:absolute;left:60px;top:20px;width:30px;height:30px;background:#4A73FF;border-radius:50%;border:2px solid #061F79;animation:visPulse 4s ease-in-out infinite .3s"></div>
            <div style="position:absolute;left:100px;top:18px;width:40px;height:25px;background:#051C2C;border-radius:3px;border:2px solid #061F79;animation:visPulse 4s ease-in-out infinite .6s"></div>
            <div style="position:absolute;left:10px;top:10px;width:140px;height:50px;border:1.5px dashed #2251FF;border-radius:3px;animation:insertAppear 4s ease-in-out infinite"></div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:6px;color:#8A95A0">Click+Drag or Shift+Click</div>
            <span class="vis-label">SELECT MULTI</span>
        </div></div>`,

    "Move Horizontally / Vertically": () => `<div class="vis">${visTitleBar('Mouse')}
        <div class="vis-canvas">
            <div style="position:absolute;left:30px;top:30px;width:45px;height:35px;background:#2251FF;border-radius:3px;animation:distributeH 4s ease-in-out infinite;--from-x:30px;--to-x:100px;display:flex;align-items:center;justify-content:center">
                <span style="font-size:6px;color:white;font-weight:700">OBJ</span>
            </div>
            <div style="position:absolute;left:25px;top:48px;width:130px;height:0;border-top:1.5px dashed #B8CAFF"></div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:6px;color:#8A95A0">Constrained to axis</div>
            <span class="vis-label">SHIFT+DRAG</span>
        </div></div>`,

    "Copy Object": () => `<div class="vis">${visTitleBar('Mouse')}
        <div class="vis-canvas">
            <div style="position:absolute;left:25px;top:25px;width:45px;height:35px;background:#2251FF;border-radius:3px;display:flex;align-items:center;justify-content:center">
                <span style="font-size:6px;color:white;font-weight:700">OBJ</span>
            </div>
            <div style="position:absolute;left:50%;top:38px;transform:translateX(-50%);font-size:12px;color:#2251FF">&#10140;</div>
            <div style="position:absolute;right:25px;top:25px;width:45px;height:35px;background:#4A73FF;border-radius:3px;display:flex;align-items:center;justify-content:center;animation:insertAppear 4s ease-in-out infinite">
                <span style="font-size:6px;color:white;font-weight:700">COPY</span>
            </div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:6px;color:#8A95A0">Ctrl + drag element</div>
            <span class="vis-label">CTRL+DRAG</span>
        </div></div>`,

    "Copy + Move Horizontally / Vertically": () => `<div class="vis">${visTitleBar('Mouse')}
        <div class="vis-canvas">
            <div style="position:absolute;left:20px;top:28px;width:40px;height:30px;background:#2251FF;border-radius:3px;display:flex;align-items:center;justify-content:center">
                <span style="font-size:6px;color:white;font-weight:700">OBJ</span>
            </div>
            <div style="position:absolute;left:20px;top:58px;width:130px;height:0;border-top:1.5px dashed #B8CAFF"></div>
            <div style="position:absolute;right:20px;top:28px;width:40px;height:30px;background:#4A73FF;border-radius:3px;display:flex;align-items:center;justify-content:center;animation:insertAppear 4s ease-in-out infinite">
                <span style="font-size:6px;color:white;font-weight:700">COPY</span>
            </div>
            <div style="position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:6px;color:#8A95A0">Copy + constrained axis</div>
            <span class="vis-label">CTRL+SHIFT+DRAG</span>
        </div></div>`,

    "Zoom In / Out": () => `<div class="vis">${visTitleBar('Mouse')}
        <div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
            <div style="animation:zoomFit 4s ease-in-out infinite;text-align:center">
                <div style="font-size:28px;color:#2251FF">&#128269;</div>
                <div style="font-size:6px;color:#8A95A0;margin-top:4px">Ctrl + scroll wheel</div>
            </div>
            <span class="vis-label">ZOOM</span>
        </div></div>`
};

// ===== VISUAL HELPER GENERATORS =====

function makeAlignVisual(direction) {
    const tb = visTitleBar('Alignment');
    const shapes = [
        { color: '#4A73FF', w: 35, h: 25 },
        { color: '#2251FF', w: 30, h: 30 },
        { color: '#051C2C', w: 40, h: 20 }
    ];
    // Scattered start positions
    const starts = [
        { x: 20, y: 12 },
        { x: 80, y: 40 },
        { x: 45, y: 72 }
    ];

    let anim, label, arrow;
    const canvasW = 160, canvasH = 100;

    switch (direction) {
        case 'left':
            anim = starts.map((s, i) => `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignL 4s ease-in-out infinite;--from-x:${s.x}px`);
            label = 'ALIGN LEFT'; arrow = '&#8612;';
            break;
        case 'right':
            anim = starts.map((s, i) => {
                const toX = canvasW - shapes[i].w - 12;
                return `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignR 4s ease-in-out infinite;--from-x:${s.x}px;--to-x:${toX}px`;
            });
            label = 'ALIGN RIGHT'; arrow = '&#8614;';
            break;
        case 'center':
            anim = starts.map((s, i) => `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignCX 4s ease-in-out infinite;--from-x:${s.x}px`);
            label = 'ALIGN HORIZ'; arrow = '&#8596;';
            break;
        case 'top':
            anim = starts.map((s, i) => `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignT 4s ease-in-out infinite;--from-y:${s.y}px`);
            label = 'ALIGN TOP'; arrow = '&#8613;';
            break;
        case 'bottom':
            anim = starts.map((s, i) => {
                const toY = canvasH - shapes[i].h - 8;
                return `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignB 4s ease-in-out infinite;--from-y:${s.y}px;--to-y:${toY}px`;
            });
            label = 'ALIGN BOTTOM'; arrow = '&#8615;';
            break;
        case 'middle':
            anim = starts.map((s, i) => `position:absolute;left:${s.x}px;top:${s.y}px;width:${shapes[i].w}px;height:${shapes[i].h}px;background:${shapes[i].color};border-radius:3px;animation:alignMY 4s ease-in-out infinite;--from-y:${s.y}px`);
            label = 'ALIGN VERT'; arrow = '&#8597;';
            break;
    }

    return `<div class="vis">${tb}<div class="vis-canvas">
        ${anim.map(a => `<div style="${a}"></div>`).join('')}
        <div style="position:absolute;right:15px;top:50%;transform:translateY(-50%);font-size:16px;color:#2251FF;animation:visPulse 4s ease-in-out infinite">${arrow}</div>
        <span class="vis-label">${label}</span>
    </div></div>`;
}

function makePrintVisual(slidesPerPage) {
    const tb = visTitleBar('Print');
    let slides = '';
    if (slidesPerPage === 1) {
        slides = `<div style="width:70px;height:50px;background:white;border:1.5px solid #2251FF;border-radius:2px;display:flex;align-items:center;justify-content:center;font-size:7px;color:#2251FF">Slide 1</div>`;
    } else if (slidesPerPage === 2) {
        slides = `<div style="display:flex;flex-direction:column;gap:4px">
            <div style="width:65px;height:24px;background:white;border:1px solid #2251FF;border-radius:2px;font-size:6px;display:flex;align-items:center;justify-content:center;color:#2251FF">Slide 1</div>
            <div style="width:65px;height:24px;background:white;border:1px solid #2251FF;border-radius:2px;font-size:6px;display:flex;align-items:center;justify-content:center;color:#2251FF">Slide 2</div>
        </div>`;
    } else {
        slides = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:3px">
            ${[1,2,3,4].map(n => `<div style="width:32px;height:22px;background:white;border:1px solid #2251FF;border-radius:1px;font-size:5px;display:flex;align-items:center;justify-content:center;color:#2251FF">${n}</div>`).join('')}
        </div>`;
    }
    return `<div class="vis">${tb}<div class="vis-canvas" style="display:flex;align-items:center;justify-content:center;gap:12px">
        <div style="width:85px;height:90px;background:#f9f9f9;border:1.5px solid #ddd;border-radius:3px;display:flex;align-items:center;justify-content:center;animation:insertAppear 4s ease-in-out infinite">
            ${slides}
        </div>
        <div style="text-align:center">
            <div style="font-size:20px;color:#2251FF">&#128424;</div>
            <div style="font-size:6px;color:#888;margin-top:3px">${slidesPerPage} per page</div>
        </div>
        <span class="vis-label">PRINT</span>
    </div></div>`;
}

function makeOrderVisual(direction) {
    const tb = visTitleBar('Ordering');
    const isFront = direction === 'front' || direction === 'forward';
    const label = direction === 'front' ? 'BRING FRONT' : direction === 'forward' ? 'BRING FWD' : direction === 'back' ? 'SEND BACK' : 'SEND BKWD';

    const highlightColor = isFront ? '#4A73FF' : '#4A73FF';
    const animName = isFront ? 'bringFront' : 'sendBack';

    return `<div class="vis">${tb}<div class="vis-canvas">
        <div style="position:absolute;left:25px;top:18px;width:50px;height:40px;background:#CFD8DC;border:1.5px solid #B0BEC5;border-radius:3px;z-index:2"></div>
        <div style="position:absolute;left:45px;top:28px;width:50px;height:40px;background:#90A4AE;border:1.5px solid #78909C;border-radius:3px;z-index:3"></div>
        <div style="position:absolute;left:65px;top:38px;width:50px;height:40px;background:${highlightColor};border:2px solid ${isFront ? '#061F79' : '#061F79'};border-radius:3px;animation:${animName} 4s ease-in-out infinite;display:flex;align-items:center;justify-content:center">
            <span style="font-size:7px;color:white;font-weight:700">&#9733;</span>
        </div>
        <div style="position:absolute;right:15px;top:20px;font-size:${isFront ? '18' : '16'}px;color:${isFront ? '#2251FF' : '#061F79'};animation:visPulse 4s ease-in-out infinite">${isFront ? '&#8593;' : '&#8595;'}</div>
        <div style="position:absolute;right:10px;top:42px;font-size:6px;color:#888">${isFront ? 'To front' : 'To back'}</div>
        <span class="vis-label">${label}</span>
    </div></div>`;
}

// Render a visual for a given shortcut title
function renderVisual(title) {
    const gen = VISUALS[title];
    if (gen) return gen();
    // Fallback: show the category icon
    const shortcut = SHORTCUTS.find(s => s.title === title);
    const cat = shortcut ? shortcut.category : 'Tools';
    return `<div class="vis">${visTitleBar(cat)}<div class="vis-canvas" style="display:flex;align-items:center;justify-content:center">
        <div style="text-align:center;color:#888"><div style="font-size:24px;margin-bottom:4px">&#9881;</div><div style="font-size:7px">${title}</div></div>
        <span class="vis-label">${cat.toUpperCase()}</span>
    </div></div>`;
}

// ===== STATE =====
let state = {
    progress: {},
    streak: 0,
    bestSpeed: 0,
    currentCard: 0,
    cardDeck: [],
    practiceIndex: 0,
    practiceQueue: [],
    practiceCorrect: 0,
    practiceWrong: 0,
    practiceAnswered: false,
    quizQuestions: [],
    quizIndex: 0,
    quizScore: 0,
    quizAnswered: false,
    speedScore: 0,
    speedTimer: null,
    speedTimeLeft: 60,
    activeCategory: null,
    mustHaveOnly: false,
    platform: 'windows'
};

// ===== INIT =====
function init() {
    SCORM.init();
    loadProgress();
    SCORM.reportProgress(getMasteredCount(), getPlatformShortcuts().length);
    addSVGDefs();
    renderPlatformToggle();
    setupNav();
    setupDashboard();
    setupLearn();
    setupPractice();
    setupQuiz();
    setupSpeed();
    updateHeaderStats();
}

function renderPlatformToggle() {
    const container = document.getElementById('platformToggle');
    if (!container) return;
    container.innerHTML = `
        <div class="platform-toggle">
            <button class="platform-btn ${state.platform === 'windows' ? 'active' : ''}" data-platform="windows"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801"/></svg> Windows</button>
            <button class="platform-btn ${state.platform === 'mac' ? 'active' : ''}" data-platform="mac"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg> Mac</button>
        </div>
    `;
    container.querySelectorAll('.platform-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (btn.dataset.platform === state.platform) return;
            state.platform = btn.dataset.platform;
            saveProgress();
            renderPlatformToggle();
            setupDashboard();
            updateHeaderStats();
            const activeView = document.querySelector('.view.active');
            if (activeView) {
                const mode = activeView.id;
                if (mode === 'learn') initLearnDeck();
                if (mode === 'practice') initPractice();
                if (mode === 'quiz') initQuiz();
                if (mode === 'speed') initSpeed();
            }
        });
    });
}

function addSVGDefs() {
    const svg = document.querySelector('.progress-ring');
    if (svg) {
        const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        const gradient = document.createElementNS('http://www.w3.org/2000/svg', 'linearGradient');
        gradient.id = 'progressGradient';
        gradient.setAttribute('x1', '0%'); gradient.setAttribute('y1', '0%');
        gradient.setAttribute('x2', '100%'); gradient.setAttribute('y2', '100%');
        const stop1 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
        stop1.setAttribute('offset', '0%'); stop1.setAttribute('stop-color', '#2251FF');
        const stop2 = document.createElementNS('http://www.w3.org/2000/svg', 'stop');
        stop2.setAttribute('offset', '100%'); stop2.setAttribute('stop-color', '#6B8FFF');
        gradient.appendChild(stop1); gradient.appendChild(stop2);
        defs.appendChild(gradient); svg.insertBefore(defs, svg.firstChild);
    }
}

// ===== PERSISTENCE =====
function loadProgress() {
    try {
        const saved = localStorage.getItem('pptx-shortcut-master');
        if (saved) {
            const data = JSON.parse(saved);
            state.progress = data.progress || {};
            state.streak = data.streak || 0;
            state.bestSpeed = data.bestSpeed || 0;
            state.platform = data.platform || 'windows';
        }
    } catch (e) { /* ignore */ }
    SHORTCUTS.forEach(s => {
        if (!state.progress[s.title]) {
            state.progress[s.title] = { status: 'new', correctStreak: 0, lastSeen: 0 };
        }
    });
    const validTitles = new Set(SHORTCUTS.map(s => s.title));
    Object.keys(state.progress).forEach(key => {
        if (!validTitles.has(key)) delete state.progress[key];
    });
}

function saveProgress() {
    try {
        localStorage.setItem('pptx-shortcut-master', JSON.stringify({
            progress: state.progress, streak: state.streak, bestSpeed: state.bestSpeed, platform: state.platform
        }));
    } catch (e) { /* ignore */ }
}

function resetAllProgress() {
    if (confirm('Reset all progress? This cannot be undone.')) {
        state.progress = {};
        state.streak = 0;
        state.bestSpeed = 0;
        SHORTCUTS.forEach(s => {
            state.progress[s.title] = { status: 'new', correctStreak: 0, lastSeen: 0 };
        });
        saveProgress();
        setupDashboard();
        updateHeaderStats();
    }
}

// ===== HELPERS =====
function shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function getPlatformShortcuts() {
    if (state.platform === 'mac') return SHORTCUTS.filter(s => s.macKey);
    return SHORTCUTS;
}

function getShortcutKey(shortcut) {
    return state.platform === 'mac' ? (shortcut.macKey || shortcut.key) : shortcut.key;
}

function getShortcutAltKey(shortcut) {
    return state.platform === 'mac' ? (shortcut.macAltKey || null) : (shortcut.altKey || null);
}

function getDisplayKey(shortcut) {
    const key = getShortcutKey(shortcut);
    const altKey = getShortcutAltKey(shortcut);
    return altKey ? `${key} or ${altKey}` : key;
}

function getFilteredShortcuts() {
    let shortcuts = [...SHORTCUTS];
    if (state.platform === 'mac') shortcuts = shortcuts.filter(s => s.macKey);
    if (state.activeCategory) shortcuts = shortcuts.filter(s => s.category === state.activeCategory);
    if (state.mustHaveOnly) shortcuts = shortcuts.filter(s => s.mustHave);
    return shortcuts;
}

function getMasteredCount() { return getPlatformShortcuts().filter(s => state.progress[s.title] && state.progress[s.title].status === 'mastered').length; }
function getLearningCount() { return getPlatformShortcuts().filter(s => state.progress[s.title] && state.progress[s.title].status === 'learning').length; }
function getNewCount() { return getPlatformShortcuts().filter(s => state.progress[s.title] && state.progress[s.title].status === 'new').length; }

function updateHeaderStats() {
    document.getElementById('masteredCount').textContent = getMasteredCount();
    document.getElementById('streakCount').textContent = state.streak;
    const total = getPlatformShortcuts().length;
    const masteredLabel = document.getElementById('masteredCountLabel');
    if (masteredLabel) masteredLabel.textContent = total;
    const heroCount = document.getElementById('heroShortcutCount');
    if (heroCount) heroCount.textContent = total;
}

function markCorrect(title) {
    const p = state.progress[title];
    p.correctStreak++;
    p.lastSeen = Date.now();
    if (p.correctStreak >= 3) p.status = 'mastered';
    else if (p.status === 'new') p.status = 'learning';
    state.streak++;
    saveProgress(); updateHeaderStats();
    SCORM.reportProgress(getMasteredCount(), getPlatformShortcuts().length);
}

function markWrong(title) {
    const p = state.progress[title];
    p.correctStreak = 0;
    p.lastSeen = Date.now();
    if (p.status === 'new') p.status = 'learning';
    state.streak = 0;
    saveProgress(); updateHeaderStats();
}

// ===== NAVIGATION =====
function setupNav() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => switchView(btn.dataset.mode));
    });
    document.querySelectorAll('.mode-card[data-launch]').forEach(btn => {
        btn.addEventListener('click', () => switchView(btn.dataset.launch));
    });
}

function switchView(mode) {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    const activeNav = document.querySelector(`.nav-btn[data-mode="${mode}"]`);
    if (activeNav) activeNav.classList.add('active');
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const view = document.getElementById(mode);
    if (view) view.classList.add('active');
    if (mode === 'learn') initLearnDeck();
    if (mode === 'practice') initPractice();
    if (mode === 'quiz') initQuiz();
    if (mode === 'speed') initSpeed();
    if (mode === 'dashboard') setupDashboard();
}

// ===== DASHBOARD =====
function setupDashboard() {
    updateProgressRing();
    renderMustHaveToggle();
    renderCategoryChips();
    renderShortcutTable();
    updateFooter();
    document.getElementById('resetProgress').onclick = resetAllProgress;
}

function updateFooter() {
    const footer = document.getElementById('siteFootnote');
    if (!footer) return;
    if (state.platform === 'mac') {
        footer.innerHTML = `
            <p>Showing ${getPlatformShortcuts().length} shortcuts with Mac equivalents. ${SHORTCUTS.length - getPlatformShortcuts().length} plugin/add-in shortcuts are Windows-only and hidden in Mac mode.</p>
            <p class="mac-note">To access all ${getPlatformShortcuts().length} Mac keyboard shortcuts, <a href="https://mckinsey.service-now.com/ghd/en/keyboard-shortcuts-stopped-working-in-powerpoint-on-macos?id=mck_ghd_kb_article&sysparm_article=KO101191&sys_kb_id=c4e3be63975c9a50120bf1a3f153af19" target="_blank" rel="noopener noreferrer">download the McKinsey macOS customized PowerPoint keyboard shortcuts</a>.</p>
        `;
    } else {
        footer.innerHTML = `
            <p>These shortcuts can vary based on computer type (Windows and Mac) and computer settings (keyboard language/layout). These shortcuts have been tested with Windows and Mac on an American keyboard (QWERTY layout).</p>
        `;
    }
}

function renderMustHaveToggle() {
    const container = document.getElementById('mustHaveToggle');
    if (!container) return;
    container.innerHTML = `
        <label class="toggle-switch-label">
            <span class="toggle-switch">
                <input type="checkbox" id="mustHaveCheck" ${state.mustHaveOnly ? 'checked' : ''}>
                <span class="toggle-slider"></span>
            </span>
            <span class="toggle-text">Must-Haves Only</span>
            <span class="toggle-hint">Applies across all modes</span>
        </label>
    `;
    document.getElementById('mustHaveCheck').addEventListener('change', (e) => {
        state.mustHaveOnly = e.target.checked;
        renderCategoryChips();
        renderShortcutTable();
        // Re-init whichever mode is active
        const activeView = document.querySelector('.view.active');
        if (activeView) {
            const mode = activeView.id;
            if (mode === 'learn') initLearnDeck();
            if (mode === 'practice') initPractice();
            if (mode === 'quiz') initQuiz();
            if (mode === 'speed') initSpeed();
        }
    });
}

function updateProgressRing() {
    const total = getPlatformShortcuts().length;
    const mastered = getMasteredCount();
    const learning = getLearningCount();
    const newCount = total - mastered - learning;
    const percent = total > 0 ? Math.round((mastered / total) * 100) : 0;
    document.getElementById('progressPercent').textContent = percent + '%';
    document.getElementById('newCount').textContent = newCount;
    document.getElementById('learningCount').textContent = learning;
    document.getElementById('masteredCountDash').textContent = mastered;
    const ring = document.getElementById('progressRingFill');
    const circumference = 2 * Math.PI * 70;
    ring.style.strokeDashoffset = total > 0 ? circumference - (mastered / total) * circumference : circumference;
}

function renderCategoryChips() {
    const container = document.getElementById('categoryChips');
    container.innerHTML = '';
    const base = getPlatformShortcuts();
    const pool = state.mustHaveOnly ? base.filter(s => s.mustHave) : base;
    const allChip = document.createElement('button');
    allChip.className = 'category-chip' + (!state.activeCategory ? ' active' : '');
    allChip.textContent = `All (${pool.length})`;
    allChip.addEventListener('click', () => { state.activeCategory = null; renderCategoryChips(); renderShortcutTable(); });
    container.appendChild(allChip);
    CATEGORIES.forEach(cat => {
        const count = pool.filter(s => s.category === cat).length;
        if (state.mustHaveOnly && count === 0) return;
        const chip = document.createElement('button');
        chip.className = 'category-chip' + (state.activeCategory === cat ? ' active' : '');
        chip.textContent = `${cat} (${count})`;
        chip.addEventListener('click', () => { state.activeCategory = cat; renderCategoryChips(); renderShortcutTable(); });
        container.appendChild(chip);
    });
}

function renderShortcutTable(filter = '') {
    const tbody = document.getElementById('shortcutTableBody');
    tbody.innerHTML = '';
    let shortcuts = getFilteredShortcuts();
    if (filter) {
        const lf = filter.toLowerCase();
        shortcuts = shortcuts.filter(s => s.title.toLowerCase().includes(lf) || getShortcutKey(s).toLowerCase().includes(lf) || s.category.toLowerCase().includes(lf));
    }
    shortcuts.forEach(s => {
        const p = state.progress[s.title];
        const tr = document.createElement('tr');
        const pKey = getShortcutKey(s);
        const pAltKey = getShortcutAltKey(s);
        const keyDisplay = pAltKey ? `<span class="shortcut-key">${pKey}</span> <span style="font-size:.7rem;color:var(--text-muted)">or</span> <span class="shortcut-key">${pAltKey}</span>` : `<span class="shortcut-key">${pKey}</span>`;
        const mustHaveBadge = s.mustHave ? '<span class="must-have-badge" title="Must-have shortcut">&#9733;</span> ' : '';
        tr.innerHTML = `<td>${mustHaveBadge}${s.title}</td><td>${keyDisplay}</td><td><span class="category-badge">${s.category}</span></td><td><span class="status-badge ${p.status}">${p.status}</span></td>`;
        tbody.appendChild(tr);
    });
    const searchInput = document.getElementById('searchInput');
    searchInput.removeEventListener('input', handleSearch);
    searchInput.addEventListener('input', handleSearch);
}

function handleSearch(e) { renderShortcutTable(e.target.value); }

// ===== LEARN (FLASHCARDS) =====
function setupLearn() {
    document.getElementById('flashcard').addEventListener('click', flipCard);
    document.querySelectorAll('.recall-btn').forEach(btn => {
        btn.addEventListener('click', () => handleRecall(btn.dataset.recall));
    });
    document.getElementById('prevCard').addEventListener('click', prevCard);
    document.getElementById('skipCard').addEventListener('click', skipCard);
}

function initLearnDeck() {
    const filtered = getFilteredShortcuts();
    const newAndLearning = filtered.filter(s => state.progress[s.title].status !== 'mastered');
    const mastered = filtered.filter(s => state.progress[s.title].status === 'mastered');
    state.cardDeck = [...shuffle(newAndLearning), ...shuffle(mastered)];
    if (state.cardDeck.length === 0) state.cardDeck = shuffle(filtered);
    state.currentCard = 0;
    showCard();
}

function showCard() {
    const deck = state.cardDeck;
    if (deck.length === 0) return;
    const idx = state.currentCard % deck.length;
    const card = deck[idx];
    document.getElementById('cardFrontText').textContent = card.title;
    document.getElementById('cardBackText').textContent = getDisplayKey(card);
    document.getElementById('cardProgress').textContent = `${idx + 1} / ${deck.length}`;
    document.getElementById('cardProgressFill').style.width = ((idx + 1) / deck.length * 100) + '%';
    // Show visual on flashcard front
    const visContainer = document.getElementById('cardVisual');
    if (visContainer) visContainer.innerHTML = renderVisual(card.title);
    // Reset flip
    document.getElementById('flashcardInner').classList.remove('flipped');
    document.getElementById('recallButtons').style.display = 'none';
}

function flipCard() {
    const inner = document.getElementById('flashcardInner');
    inner.classList.toggle('flipped');
    if (inner.classList.contains('flipped')) {
        document.getElementById('recallButtons').style.display = 'flex';
    }
}

function handleRecall(level) {
    const deck = state.cardDeck;
    const idx = state.currentCard % deck.length;
    const card = deck[idx];
    if (level === 'easy') {
        markCorrect(card.title);
    } else if (level === 'hard') {
        markWrong(card.title);
        deck.push(card);
    } else {
        const p = state.progress[card.title];
        if (p.status === 'new') p.status = 'learning';
        p.lastSeen = Date.now();
        saveProgress();
    }
    state.currentCard++;
    showCard();
}

function prevCard() { if (state.currentCard > 0) state.currentCard--; showCard(); }
function skipCard() { state.currentCard++; showCard(); }

// ===== PRACTICE (TYPE SHORTCUT) =====
function setupPractice() {
    document.getElementById('showAnswer').addEventListener('click', showPracticeAnswer);
    document.getElementById('nextPractice').addEventListener('click', nextPracticeQuestion);
    document.getElementById('submitTyped').addEventListener('click', handleTypedAnswer);
    document.getElementById('typeFallback').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); handleTypedAnswer(); }
        e.stopPropagation(); // prevent practice key handler from firing
    });
    // Stop keydown events inside the text input from triggering the shortcut listener
    document.getElementById('typeFallback').addEventListener('keyup', (e) => e.stopPropagation());
}

function initPractice() {
    state.practiceQueue = shuffle(getFilteredShortcuts());
    state.practiceIndex = 0;
    state.practiceCorrect = 0;
    state.practiceWrong = 0;
    state.practiceAnswered = false;
    document.getElementById('practiceCorrect').textContent = '0';
    document.getElementById('practiceWrong').textContent = '0';
    showPracticeQuestion();
    startKeyListener();
}

function showPracticeQuestion() {
    const q = state.practiceQueue;
    if (q.length === 0) return;
    const idx = state.practiceIndex % q.length;
    const shortcut = q[idx];
    document.getElementById('practiceAction').textContent = shortcut.title;
    // Show visual
    const visContainer = document.getElementById('practiceVisual');
    if (visContainer) visContainer.innerHTML = renderVisual(shortcut.title);
    document.getElementById('keyDisplay').innerHTML = '<span class="key-placeholder">Press the shortcut keys...</span>';
    document.getElementById('keyDisplay').className = 'key-display listening';
    document.getElementById('practiceFeedback').textContent = '';
    document.getElementById('practiceFeedback').className = 'practice-feedback';
    const fallbackInput = document.getElementById('typeFallback');
    if (fallbackInput) fallbackInput.value = '';
    state.practiceAnswered = false;
}

function startKeyListener() {
    document.removeEventListener('keydown', handlePracticeKey);
    document.addEventListener('keydown', handlePracticeKey);
}

function handlePracticeKey(e) {
    const practiceView = document.getElementById('practice');
    if (!practiceView.classList.contains('active')) return;
    if (state.practiceAnswered) return;
    // Don't intercept when typing in the fallback text input
    if (e.target.id === 'typeFallback') return;
    e.preventDefault();
    const parts = [];
    if (state.platform === 'mac') {
        if (e.ctrlKey) parts.push('Control');
        if (e.metaKey) parts.push('Cmd');
        if (e.altKey) parts.push('Option');
        if (e.shiftKey) parts.push('Shift');
    } else {
        if (e.ctrlKey || e.metaKey) parts.push('Ctrl');
        if (e.altKey) parts.push('Alt');
        if (e.shiftKey) parts.push('Shift');
    }
    const keyMap = { 'ArrowLeft':'Left Arrow', 'ArrowRight':'Right Arrow', 'ArrowUp':'Up Arrow', 'ArrowDown':'Down Arrow', 'BracketRight':']', 'BracketLeft':'[', ' ':'Space', 'Space':'Space' };
    let key = e.key;
    if (keyMap[key]) key = keyMap[key];
    else if (keyMap[e.code]) key = keyMap[e.code];
    else if (key === 'Tab') key = 'Tab';
    else if (key.length === 1) key = key.toUpperCase();
    if (state.platform === 'mac' && key === 'Space') key = 'Spacebar';
    if (['Control', 'Alt', 'Shift', 'Meta'].includes(key)) {
        document.getElementById('keyDisplay').innerHTML = `<span style="color:var(--accent)">${parts.join('+') + '+...'}</span>`;
        return;
    }
    parts.push(key);
    const pressed = parts.join('+');
    const display = document.getElementById('keyDisplay');
    display.innerHTML = `<span>${pressed}</span>`;
    const q = state.practiceQueue;
    const idx = state.practiceIndex % q.length;
    const shortcut = q[idx];
    const displayKey = getDisplayKey(shortcut);
    if (isCorrectKey(pressed, shortcut)) {
        display.className = 'key-display correct';
        document.getElementById('practiceFeedback').textContent = 'Correct!';
        document.getElementById('practiceFeedback').className = 'practice-feedback correct';
        state.practiceCorrect++;
        document.getElementById('practiceCorrect').textContent = state.practiceCorrect;
        markCorrect(shortcut.title);
        state.practiceAnswered = true;
    } else {
        display.className = 'key-display wrong';
        document.getElementById('practiceFeedback').innerHTML = `Wrong — the answer is <strong>${displayKey}</strong>`;
        document.getElementById('practiceFeedback').className = 'practice-feedback wrong';
        state.practiceWrong++;
        document.getElementById('practiceWrong').textContent = state.practiceWrong;
        markWrong(shortcut.title);
        state.practiceAnswered = true;
    }
}

function normalizeKey(k) {
    return k.toLowerCase().replace(/\s+/g, '')
        .replace('arrowleft', 'leftarrow').replace('arrowright', 'rightarrow')
        .replace('arrowup', 'uparrow').replace('arrowdown', 'downarrow')
        .replace('spacebar', 'space');
}

function isCorrectKey(pressed, shortcut) {
    const norm = normalizeKey(pressed);
    const key = getShortcutKey(shortcut);
    const altKey = getShortcutAltKey(shortcut);
    if (norm === normalizeKey(key)) return true;
    if (altKey && norm === normalizeKey(altKey)) return true;
    // Accept any Alt+Arrow for "Jump Between Objects" in Windows mode
    if (state.platform !== 'mac' && shortcut.key === 'Alt+Arrow Key' && /^alt\+(left|right|up|down)arrow$/.test(norm)) return true;
    // Handle "or" composite keys (Mouse shortcuts, Tab or Shift+Tab, etc.)
    if (key.includes(' or ')) {
        const parts = key.split(' or ').map(s => s.trim());
        return parts.some(p => norm === normalizeKey(p));
    }
    return false;
}

function showPracticeAnswer() {
    const q = state.practiceQueue;
    const idx = state.practiceIndex % q.length;
    const shortcut = q[idx];
    const displayKey = getDisplayKey(shortcut);
    document.getElementById('keyDisplay').innerHTML = `<span style="color:var(--accent)">${displayKey}</span>`;
    document.getElementById('keyDisplay').className = 'key-display';
    document.getElementById('practiceFeedback').textContent = 'Answer revealed';
    document.getElementById('practiceFeedback').className = 'practice-feedback';
    state.practiceAnswered = true;
}

function handleTypedAnswer() {
    if (state.practiceAnswered) return;
    const input = document.getElementById('typeFallback');
    const typed = input.value.trim();
    if (!typed) return;
    const q = state.practiceQueue;
    const idx = state.practiceIndex % q.length;
    const shortcut = q[idx];
    const displayKey = getDisplayKey(shortcut);
    const display = document.getElementById('keyDisplay');
    display.innerHTML = `<span>${typed}</span>`;
    if (isCorrectKey(typed, shortcut)) {
        display.className = 'key-display correct';
        document.getElementById('practiceFeedback').textContent = 'Correct!';
        document.getElementById('practiceFeedback').className = 'practice-feedback correct';
        state.practiceCorrect++;
        document.getElementById('practiceCorrect').textContent = state.practiceCorrect;
        markCorrect(shortcut.title);
    } else {
        display.className = 'key-display wrong';
        document.getElementById('practiceFeedback').innerHTML = `Wrong — the answer is <strong>${displayKey}</strong>`;
        document.getElementById('practiceFeedback').className = 'practice-feedback wrong';
        state.practiceWrong++;
        document.getElementById('practiceWrong').textContent = state.practiceWrong;
        markWrong(shortcut.title);
    }
    state.practiceAnswered = true;
}

function nextPracticeQuestion() { state.practiceIndex++; showPracticeQuestion(); }

// ===== QUIZ =====
function setupQuiz() {
    document.getElementById('quizNext').addEventListener('click', nextQuizQuestion);
    document.getElementById('retakeQuiz').addEventListener('click', initQuiz);
}

function initQuiz() {
    const pool = shuffle(getFilteredShortcuts());
    state.quizQuestions = pool.slice(0, Math.min(10, pool.length));
    state.quizIndex = 0;
    state.quizScore = 0;
    state.quizAnswered = false;
    document.getElementById('quizResults').style.display = 'none';
    document.querySelector('.quiz-area').style.display = 'block';
    showQuizQuestion();
}

function showQuizQuestion() {
    if (state.quizIndex >= state.quizQuestions.length) { showQuizResults(); return; }
    const current = state.quizQuestions[state.quizIndex];
    document.getElementById('quizAction').textContent = current.title;
    // Show visual
    const visContainer = document.getElementById('quizVisual');
    if (visContainer) visContainer.innerHTML = renderVisual(current.title);
    document.getElementById('quizProgressText').textContent = `Question ${state.quizIndex + 1} / ${state.quizQuestions.length}`;
    document.getElementById('quizScoreText').textContent = `Score: ${state.quizScore}`;
    document.getElementById('quizProgressFill').style.width = ((state.quizIndex + 1) / state.quizQuestions.length * 100) + '%';
    document.getElementById('quizNext').style.display = 'none';
    state.quizAnswered = false;
    const correctKey = getShortcutKey(current);
    const pool = getFilteredShortcuts();
    const wrongPool = pool.filter(s => getShortcutKey(s) !== correctKey);
    const wrongOptions = shuffle(wrongPool).slice(0, 3).map(s => getShortcutKey(s));
    const options = shuffle([correctKey, ...wrongOptions]);
    const container = document.getElementById('quizOptions');
    container.innerHTML = '';
    options.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'quiz-option';
        btn.textContent = opt;
        btn.addEventListener('click', () => handleQuizAnswer(btn, opt, correctKey, current.title));
        container.appendChild(btn);
    });
}

function handleQuizAnswer(btn, selected, correct, title) {
    if (state.quizAnswered) return;
    state.quizAnswered = true;
    document.querySelectorAll('.quiz-option').forEach(b => b.classList.add('disabled'));
    if (selected === correct) {
        btn.classList.add('selected-correct');
        state.quizScore++;
        markCorrect(title);
    } else {
        btn.classList.add('selected-wrong');
        markWrong(title);
        document.querySelectorAll('.quiz-option').forEach(b => { if (b.textContent === correct) b.classList.add('reveal-correct'); });
    }
    document.getElementById('quizScoreText').textContent = `Score: ${state.quizScore}`;
    document.getElementById('quizNext').style.display = 'block';
}

function nextQuizQuestion() { state.quizIndex++; showQuizQuestion(); }

function showQuizResults() {
    document.querySelector('.quiz-area').style.display = 'none';
    document.getElementById('quizResults').style.display = 'flex';
    const total = state.quizQuestions.length;
    const correct = state.quizScore;
    const wrong = total - correct;
    const accuracy = Math.round((correct / total) * 100);
    document.getElementById('resultCorrect').textContent = correct;
    document.getElementById('resultWrong').textContent = wrong;
    document.getElementById('resultAccuracy').textContent = accuracy + '%';
    if (accuracy >= 80) { document.getElementById('resultsTitle').textContent = 'Excellent!'; document.getElementById('resultsSubtitle').textContent = `You scored ${correct} out of ${total}!`; }
    else if (accuracy >= 60) { document.getElementById('resultsTitle').textContent = 'Good Effort!'; document.getElementById('resultsSubtitle').textContent = `You scored ${correct} out of ${total}. Keep practicing!`; }
    else { document.getElementById('resultsTitle').textContent = 'Keep Learning!'; document.getElementById('resultsSubtitle').textContent = `You scored ${correct} out of ${total}. Review the flashcards and try again.`; }
    const missedContainer = document.getElementById('resultsMissed');
    missedContainer.innerHTML = '';
    if (wrong > 0) {
        const missed = state.quizQuestions.filter(q => state.progress[q.title].status !== 'mastered');
        if (missed.length > 0) {
            missedContainer.innerHTML = '<h4>Review These:</h4>';
            missed.slice(0, wrong).forEach(m => {
                const div = document.createElement('div');
                div.className = 'missed-item';
                div.innerHTML = `<span>${m.title}</span><span class="shortcut-key">${getShortcutKey(m)}</span>`;
                missedContainer.appendChild(div);
            });
        }
    }
}

// ===== SPEED RUN =====
function setupSpeed() {
    document.getElementById('startSpeed').addEventListener('click', startSpeedRun);
    document.getElementById('retrySpeed').addEventListener('click', initSpeed);
}

function initSpeed() {
    document.getElementById('speedPre').style.display = 'block';
    document.getElementById('speedGame').style.display = 'none';
    document.getElementById('speedResults').style.display = 'none';
    document.getElementById('bestScore').textContent = state.bestSpeed;
    if (state.speedTimer) clearInterval(state.speedTimer);
}

function startSpeedRun() {
    state.speedScore = 0;
    state.speedTimeLeft = 60;
    document.getElementById('speedPre').style.display = 'none';
    document.getElementById('speedGame').style.display = 'block';
    document.getElementById('speedResults').style.display = 'none';
    document.getElementById('speedScore').textContent = '0';
    document.getElementById('speedTimer').textContent = '60';
    document.getElementById('speedTimer').className = 'speed-timer';
    showSpeedQuestion();
    startSpeedTimer();
}

function startSpeedTimer() {
    state.speedTimer = setInterval(() => {
        state.speedTimeLeft--;
        const timerEl = document.getElementById('speedTimer');
        timerEl.textContent = state.speedTimeLeft;
        if (state.speedTimeLeft <= 10) timerEl.className = 'speed-timer danger';
        else if (state.speedTimeLeft <= 20) timerEl.className = 'speed-timer warning';
        if (state.speedTimeLeft <= 0) { clearInterval(state.speedTimer); endSpeedRun(); }
    }, 1000);
}

function showSpeedQuestion() {
    const pool = getFilteredShortcuts();
    const current = pool[Math.floor(Math.random() * pool.length)];
    document.getElementById('speedAction').textContent = current.title;
    // Show visual in speed mode
    const visContainer = document.getElementById('speedVisual');
    if (visContainer) visContainer.innerHTML = renderVisual(current.title);
    const correctKey = getShortcutKey(current);
    const speedPool = getFilteredShortcuts();
    const wrongPool = speedPool.filter(s => getShortcutKey(s) !== correctKey);
    const wrongOptions = shuffle(wrongPool).slice(0, 3).map(s => getShortcutKey(s));
    const options = shuffle([correctKey, ...wrongOptions]);
    const container = document.getElementById('speedOptions');
    container.innerHTML = '';
    options.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'speed-option';
        btn.textContent = opt;
        btn.addEventListener('click', () => handleSpeedAnswer(btn, opt, correctKey, current.title));
        container.appendChild(btn);
    });
}

function handleSpeedAnswer(btn, selected, correct, title) {
    if (selected === correct) {
        btn.classList.add('flash-correct');
        state.speedScore++;
        document.getElementById('speedScore').textContent = state.speedScore;
        markCorrect(title);
        setTimeout(showSpeedQuestion, 200);
    } else {
        btn.classList.add('flash-wrong');
        markWrong(title);
        document.querySelectorAll('.speed-option').forEach(b => { if (b.textContent === correct) b.classList.add('flash-correct'); });
        setTimeout(showSpeedQuestion, 600);
    }
}

function endSpeedRun() {
    document.getElementById('speedGame').style.display = 'none';
    document.getElementById('speedResults').style.display = 'block';
    document.getElementById('speedFinalScore').textContent = state.speedScore;
    const newBestEl = document.getElementById('speedNewBest');
    if (state.speedScore > state.bestSpeed) {
        state.bestSpeed = state.speedScore;
        saveProgress();
        newBestEl.style.display = 'block';
    } else { newBestEl.style.display = 'none'; }
}

// ===== BOOTSTRAP =====
document.addEventListener('DOMContentLoaded', init);
window.addEventListener('beforeunload', function () { SCORM.terminate(); });
